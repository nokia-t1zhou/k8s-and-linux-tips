#!/bin/bash

echo "MIM Container Set ENVS for Runtime."
export MACA_PATH=/opt/maca
export MACA_CLANG_PATH=${MACA_PATH}/mxgpu_llvm/bin
export PATH=${MACA_PATH}/bin:${MACA_PATH}/tools/cu-bridge/bin:${MACA_PATH}/tools/cu-bridge/tools:${MACA_CLANG_PATH}:${PATH}
export LD_LIBRARY_PATH=${MACA_PATH}/lib:${MACA_PATH}/mxgpu_llvm/lib:${LD_LIBRARY_PATH}
export MXLOG_LEVEL=err
export LD_LIBRARY_PATH=/opt/maca/mxgpu_llvm/lib:$LD_LIBRARY_PATH
export MACA_PATH=/opt/maca
export CUDA_PATH=$MACA_PATH/tools/cu-bridge
export MACA_CLANG_PATH=$MACA_PATH/mxgpu_llvm/bin
export LD_LIBRARY_PATH=./:$MACA_PATH/lib:$LD_LIBRARY_PATH
export PATH=$CUDA_PATH/bin:$MACA_CLANG_PATH:$PATH
