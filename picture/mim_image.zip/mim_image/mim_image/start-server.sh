#!/bin/bash
echo "Running as user: $(whoami)"
id
set -u
export VLLM_CONFIGURE_LOGGING=1

MIM_LOG_LEVEL="${MIM_LOG_LEVEL:-DEFAULT}"

case "${MIM_LOG_LEVEL}" in
  "TRACE")
    export TLLM_LOG_LEVEL="TRACE"
    export VLLM_MXEXT_LOG_LEVEL="DEBUG"
    export UVICORN_LOG_LEVEL="trace"
    ;;
  "DEBUG")
    export TLLM_LOG_LEVEL="DEBUG"
    export VLLM_MXEXT_LOG_LEVEL="DEBUG"
    export UVICORN_LOG_LEVEL="debug"
    ;;
  "INFO")
    export TLLM_LOG_LEVEL="INFO"
    export VLLM_MXEXT_LOG_LEVEL="INFO"
    export UVICORN_LOG_LEVEL="info"
    ;;
  "DEFAULT")
    export TLLM_LOG_LEVEL="ERROR"
    export VLLM_MXEXT_LOG_LEVEL="INFO"
    export UVICORN_LOG_LEVEL="info"
    ;;
  "WARNING")
    export TLLM_LOG_LEVEL="WARNING"
    export VLLM_MXEXT_LOG_LEVEL="WARNING"
    export UVICORN_LOG_LEVEL="warning"
    ;;
  "ERROR")
    export TLLM_LOG_LEVEL="ERROR"
    export VLLM_MXEXT_LOG_LEVEL="ERROR"
    export UVICORN_LOG_LEVEL="error"
    ;;
  "CRITICAL")
    export TLLM_LOG_LEVEL="ERROR"
    export VLLM_MXEXT_LOG_LEVEL="CRITICAL"
    export UVICORN_LOG_LEVEL="critical"
    ;;
  *)
    echo "Unsupported value ('${MIM_LOG_LEVEL}') of MIM_LOG_LEVEL. Supported values are: TRACE, DEBUG, INFO, DEFAULT, WARNING, ERROR, CRITICAL." >&2
    exit 1
    ;;
esac
echo "start to starup MIM LLM container...."
python3 -m vllm_mxext.entrypoints.openai.api_server
