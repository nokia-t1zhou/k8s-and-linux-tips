#!/bin/bash

subcommand=$1
shift

ray_port=6379
ray_init_timeout=300
declare -a start_params

# 定义函数 get_ib_active_hcas，用于返回以逗号分隔的激活状态的 IB HCA 名称字符串
get_ib_active_hcas() {
  # 调用 ibstat 命令，并使用 awk 解析输出：
  # 1. 遇到以 "CA" 开头的行时，提取第二个字段（例如 'mlx5_0'），并去掉单引号；
  # 2. 遇到 "State:" 行时，如果状态为 Activate，则打印保存的 HCA 名称。
  local active_hcas
  active_hcas=$(ibstat | awk '/^CA/ { hca = $2; gsub(/'"'"'/, "", hca); } /^[[:space:]]*State:/ { if ($2 == "Active") print hca; }')

  # 使用 paste 将多行输出转换为以逗号分隔的单行字符串
  local result
  result=$(echo "$active_hcas" | paste -sd "," -)

  # 输出结果
  echo "$result"
}

case "$subcommand" in
  worker)
    ray_address=""
    while [ $# -gt 0 ]; do
      case "$1" in
        --ray_address=*)
          ray_address="${1#*=}"
          ;;
        --ray_port=*)
          ray_port="${1#*=}"
          ;;
        --ray_init_timeout=*)
          ray_init_timeout="${1#*=}"
          ;;
        --num_gpus=*)
          num_gpus="${1#*=}"
          ;;
        *)
          start_params+=("$1")
      esac
      shift
    done

    if [ -z "$ray_address" ]; then
      echo "Error: Missing argument --ray_address"
      exit 1
    fi
    network_name=$(ip -o -4 route get 8.8.8.8 | awk '{for(i=1;i<=NF;i++) if ($i=="dev") print $(i+1)}')
    echo "worker node network interface: $network_name"
    ib_ca_name=$(get_ib_active_hcas)
    echo "get ib HCA name:$ib_ca_name by ibstat cmd"
    export GLOO_SOCKET_IFNAME=$network_name
    export MCCL_SOCKET_IFNAME=$network_name
    export MCCL_IB_HCA=$ib_ca_name
    echo "worker node set env GLOO_SOCKET_IFNAME: $GLOO_SOCKET_IFNAME , set env MCCL_SOCKET_IFNAME: $MCCL_SOCKET_IFNAME, set env MCCL_IB_HCA: $MCCL_IB_HCA"
    for (( i=0; i < $ray_init_timeout; i+=5 )); do
      ray start --address=$ray_address:$ray_port --num-gpus=$num_gpus
      if [ $? -eq 0 ]; then
        echo "Worker: Ray runtime started with head address $ray_address:$ray_port"
        exit 0
      fi
      echo "Waiting until the ray worker is active..."
      sleep 5s;
    done
    echo "Ray worker starts timeout, head address: $ray_address:$ray_port"
    exit 1
    ;;

  leader)
    ray_cluster_size=""
    while [ $# -gt 0 ]; do
          case "$1" in
            --ray_port=*)
              ray_port="${1#*=}"
              ;;
            --ray_cluster_size=*)
              ray_cluster_size="${1#*=}"
              ;;
            --ray_init_timeout=*)
              ray_init_timeout="${1#*=}"
              ;;
            --num_gpus=*)
              num_gpus="${1#*=}"
              ;;
            *)
              start_params+=("$1")
          esac
          shift
    done

    if [ -z "$ray_cluster_size" ]; then
      echo "Error: Missing argument --ray_cluster_size"
      exit 1
    fi

    network_name=$(ip -o -4 route get 8.8.8.8 | awk '{for(i=1;i<=NF;i++) if ($i=="dev") print $(i+1)}')
    echo "leader node network interface: $network_name"
    ib_ca_name=$(get_ib_active_hcas)
    echo "get ib HCA name:$ib_ca_name by ibstat cmd"
    export GLOO_SOCKET_IFNAME=$network_name
    export MCCL_SOCKET_IFNAME=$network_name
    export MCCL_IB_HCA=$ib_ca_name
    echo "leader node set env GLOO_SOCKET_IFNAME: $GLOO_SOCKET_IFNAME , set env MCCL_SOCKET_IFNAME: $MCCL_SOCKET_IFNAME, set env MCCL_IB_HCA: $MCCL_IB_HCA"
    # start the ray daemon
    ray start --head --num-gpus=$num_gpus

    # wait until all workers are active
    for (( i=0; i < $ray_init_timeout; i+=5 )); do
        active_nodes=`python3 -c 'import ray; ray.init(); print(sum(node["Alive"] for node in ray.nodes()))'`
        if [ $active_nodes -eq $ray_cluster_size ]; then
          echo "All ray workers are active and the ray cluster is initialized successfully."
          exit 0
        fi
        echo "Wait for all ray workers to be active. $active_nodes/$ray_cluster_size is active"
        sleep 5s;
    done

    echo "Waiting for all ray workers to be active timed out."
    exit 1
    ;;

  *)
    echo "unknown subcommand: $subcommand"
    exit 1
    ;;
esac

