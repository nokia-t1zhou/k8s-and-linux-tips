This directory holds the NIM runtimes, these should be applied by an admin and make NIMs accessible cluster-wide
