# Deploying NIMs on AzureML

- **Using Azure CLI method** [README](./cli/README.md)
- **Jupyter notebook method** [README](./python_sdk/README.md)