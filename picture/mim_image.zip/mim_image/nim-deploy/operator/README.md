# The NVIDIA NIM Operator
The NIM Operator for Kubernetes has moved to its own dedicated repo.

All development work is now located on GitHub in the [k8s-nim-operator](https://github.com/NVIDIA/k8s-nim-operator) repo.
