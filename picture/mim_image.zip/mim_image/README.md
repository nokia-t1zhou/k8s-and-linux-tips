## MIM部署测试步骤
MIM目前只支持单机推理模型一键部署，2种部署方式：
- 手动启动container方式启动任务
- K8s集群中通过helm部署

### 支持的model
目前已经发布的mim image（基于maca2.27版本生成）：
- deepseek-r1-distill-llama-8b:maca-2.27-mim-1.0.0
- deepseek-r1-distill-qwen-1.5b:maca-2.27-mim-1.0.0
- deepseek-r1-distill-qwen-7b:maca-2.27-mim-1.0.0
- deepseek-r1-distill-qwen-14b:maca-2.27-mim-1.0.0
- deepseek-r1-distill-qwen-32b:maca-2.27-mim-1.0.0
- DeepSeek-R1-Distill-Llama-70B:maca-2.27-mim-1.0.0

这些image存放在 mxcr.metax-tech.com/mim-pub 仓库中。

### 模型配置文件

MIM模型配置文件定义了两件事：NIM可以使用哪些模型引擎，以及NIM应使用哪些标准来选择这些引擎。每个配置文件都有一个基于其内容哈希值的唯一字符串标识。

MIM为不同的GPU类型和特定的数值精度提供了优化的模型配置文件。这些优化的模型配置文件具有特定于模型和硬件的优化，以提高模型的性能。对于给定的模型，可能有多个有效的优化模型配置文件，在这种情况下，可以在部署时用容器中的环境变量"NIM_MODEL_PROFILE=ID"选择一个配置文件。如果用户在部署时未手动选择配置文件，MIM将根据硬件资源自动选择一个配置文件。

如果存在对应检测到的GPU类型的优化配置文件，将根据以下标准选择：
- 精度：优先选择较低精度的配置文件。例如，MIM会自动选择FP8配置文件，而不是FP16配置文件。对于相同位数的数值类型，浮点精度优先于其他数值类型。例如，FP8优先于INT8，FP16优先于BF16。
- 张量并行度：优先选择具有更高张量并行度（TP）值的配置文件。例如，如果有一个TP值为8的配置文件（需要8个GPU运行），而另一个TP值为4的配置文件（需要4个GPU运行），且有足够的GPU可用，则会选择TP值为8的配置文件。

模型配置文件嵌入在MIM容器的模型清单文件中，默认情况下，该文件位于容器文件系统的/opt/nim/etc/default/路径下（model_manifest.yaml）。以下是一个示例：
```bash
d8dd8af82e0035d7ca50b994d85a3740dbd84ddb4ed330e30c509e041ba79f80:
  model: deepseek-ai/DeepSeek-R1-Distill-Qwen-32B
  release: '1.0.0'
  tags:
    feat_lora: 'false'
    llm_engine: vllm
    precision: fp16
    gpu: C500
    gpu_device: 9999:4001
    tp: '4'
  workspace: !workspace
    components:
    - dst: ''
      src:
        files:
        - !name config.json
        - !name generation_config.json
        - !name configuration.json
        - !name LICENSE
        - !name model-00001-of-000008.safetensors
        - !name model-00002-of-000008.safetensors
        - !name model-00003-of-000008.safetensors
        - !name model-00004-of-000008.safetensors
        - !name model-00005-of-000008.safetensors
        - !name model-00006-of-000008.safetensors
        - !name model-00007-of-000008.safetensors
        - !name model-00008-of-000008.safetensors
        - !name model.safetensors.index.json
        - !name README.md
        - !name tokenizer_config.json
        - !name tokenizer.json
```

### 申请MIM_API_KEY
https://sw-mim.metax-tech.com

这个密钥用来从mxcr.metax-tech.com下载MIM需要的docker image，以及从mxs3.metax-tech.com下载模型文件（首先尝试从ModelScope下载，如果失败，再尝试从mxs3.metax-tech.com下载）

### 1）container方式启动任务（需要预先安装metax-docker）

使用Docker命令及特定用户名"$oauthtoken"和MIM_API_KEY登录 mxcr.metax-tech.com

```bash
$ docker login mxcr.metax-tech.com
Username: $oauthtoken
Password: <PASTE_API_KEY_HERE>
```

通过以下命令拉取并运行 Metax MIM AI应用微服务， 执行命令后框架会校验MIM_API_KEY并将优化后的模型下载到LOCAL_MIM_CACHE目录(默认目录： LOCAL_MIM_CACHE/deepseek-ai/DeepSeek-R1-Distill-Qwen-32B， MIM会检测此目录是否已经存在模型文件，不会重复下载)

```bash
$export MIM_API_KEY=<PASTE_API_KEY_HERE>
$export LOCAL_MIM_CACHE=~/.cache/mim
$mkdir -p "$LOCAL_MIM_CACHE"
$metax-docker run -it --rm -u root --maca=/opt/maca --mxdriver=/opt/mxdriver --gpus=4 --network=host --security-opt seccomp=unconfined --security-opt apparmor=unconfined --shm-size='100gb' --ulimit memlock=-1 --ulimit=stack=67108864 -e MIM_SERVER_PORT=8123 -e MIM_API_KEY=$MIM_API_KEY -v "$LOCAL_MIM_CACHE:/opt/mim/.cache"  mxcr.metax-tech.com/mim-pub/deepseek-r1-distill-qwen-32b:maca-2.27-mim-1.0.0
```


### 2）通过helm部署（需要部署device-plugin）
注意： 此方式暂时不适用部署deepseek系列模型

#### 设置集群秘钥
```bash
#docker registry秘钥
$export MIM_API_KEY=<PASTE_API_KEY_HERE>
$kubectl create secret docker-registry harbor-secret --docker-server=mxcr.metax-tech.com --docker-username=$oauthtoken --docker-password=$MIM_API_KEY
#集群下载模型秘钥
$kubectl create secret generic mim-api --from-literal=MIM_API_KEY=$MIM_API_KEY
```
设置的密钥会在YAML文件中被调用

#### 登录helm仓库

#登录helm仓库
$helm registry login mxcr.metax-tech.com #输入username:$oauthtoken, password: MIM_API_KEY
#下载k8s helm chart package
$helm pull oci://mxcr.metax-tech.com/mim-pub/deepseek-v3-bf16 --version 2.29.0


```bash
 $helm registry login mxcr.metax-tech.com
 $username:$oauthtoken
 $password: 输入MIM_API_KEY
```
查看mim repo中的chart列表
```bash
$helm search repo mim
NAME                    CHART VERSION   APP VERSION     DESCRIPTION                        
mim/mim-llama2-7b       0.1.0           1.16.0          A Helm chart for METAX MIM for LLMs 
```
NOTE: 此helm chart适用所有已经发布的mim image。

#### 下载helm chart
```bash
$helm pull oci://mxcr.metax-tech.com/mim-pub/deepseek-v3-bf16 --version 2.29.0
```

#### 部署
```bash
$helm install metax-mim llama2-7b-chat-hf-0.1.0.tgz
```


### 验证部署
通过curl命令调用open API的简单测试：

```bash
curl -X 'POST' \
'http://127.0.0.1:8123/v1/chat/completions' \
-H 'accept: application/json' \
-H 'Content-Type: application/json' \
-d '{
"model": "deepseek-ai/DeepSeek-R1-Distill-Qwen-32B",
"messages": [
{"role": "system", "content": "You are a helpful assistant."},
{"role": "user", "content": "who are you?"}
]
}'
```

