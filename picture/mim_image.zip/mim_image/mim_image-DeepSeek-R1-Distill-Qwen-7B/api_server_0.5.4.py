# SPDX-FileCopyrightText: Copyright (c) 2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: LicenseRef-NvidiaProprietary
#
# NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
# property and proprietary rights in and to this material, related
# documentation and any modifications thereto. Any use, reproduction,
# disclosure or distribution of this material and related documentation
# without an express license agreement from NVIDIA CORPORATION or
# its affiliates is strictly prohibited.

# This file is derived from: https://github.com/vllm-project/vllm/blob/main/vllm/entrypoints/api_server.py
#
#   Copyright 2024,2024 vLLM Team
#
#   Licensed under the Apache License, Version 2.0 (the "License");
#   you may not use this file except in compliance with the License.
#   You may obtain a copy of the License at
#
#       http://www.apache.org/licenses/LICENSE-2.0
#
#   Unless required by applicable law or agreed to in writing, software
#   distributed under the License is distributed on an "AS IS" BASIS,
#   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#   See the License for the specific language governing permissions and
#   limitations under the License.

import asyncio
import importlib
import inspect
import os
import re
import uuid
from contextlib import asynccontextmanager, contextmanager
from http import HTTPStatus
from textwrap import dedent
from typing import AsyncGenerator, List, Optional, Union
from typing import AsyncIterator, Set
from multiprocessing import Process

import fastapi
import uvicorn
import vllm_mxext
import argparse
from argparse import Namespace
from fastapi import APIRouter, FastAPI
from fastapi import HTTPException, Request
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, Response, StreamingResponse
#from nvidia.models_synchronizer import init_peft_synchronizer
from prometheus_client import make_asgi_app
from starlette.routing import Mount
import vllm.envs as envs
from vllm.engine.arg_utils import AsyncEngineArgs
from vllm.entrypoints.openai.cli_args import make_arg_parser
from vllm.entrypoints.openai.protocol import (
    ChatCompletionRequest,
    ChatCompletionResponse,
    ChatCompletionStreamResponse,
    CompletionRequest,
    CompletionResponse,
    CompletionStreamResponse,
    ErrorResponse,
    ModelList,
    TokenizeRequest,
    DetokenizeRequest,
    DetokenizeResponse,
    EmbeddingRequest,
    TokenizeResponse
)
from vllm.sampling_params import SamplingParams
from vllm.usage.usage_lib import UsageContext
from vllm.engine.async_llm_engine import AsyncLLMEngine
from vllm.engine.protocol import AsyncEngineClient
from vllm.entrypoints.launcher import serve_http
from vllm.entrypoints.logger import RequestLogger
#from vllm_mxext.engine.trtllm_model_runner import LoraCacheFullError, TrtllmInferenceError
from vllm_mxext.entrypoints.openai.api_extensions import (
    NIMHealthSuccessResponse,
    NIMLLMChatCompletionRequest,
    NIMLLMCompletionRequest,
    NIMLLMVersionResponse,
    #OpenAIServingChat,
    #OpenAIServingCompletion,
)
from vllm.entrypoints.openai.serving_chat import OpenAIServingChat
from vllm.entrypoints.openai.serving_completion import OpenAIServingCompletion
from vllm.entrypoints.openai.serving_embedding import OpenAIServingEmbedding
from vllm.entrypoints.openai.serving_tokenization import (
    OpenAIServingTokenization)
from vllm_mxext.engine.metrics import NimMetrics
from vllm_mxext.hub import inject_mx_hub
from vllm_mxext.hub import print_system_and_profile_summaries
from vllm_mxext.logger import (
    configure_all_loggers_with_handlers_except,
    configure_logger,
    get_logging_config_for_package,
    init_logger,
)

from vllm.utils import FlexibleArgumentParser, get_open_port
from vllm.version import __version__ as VLLM_VERSION

TIMEOUT_KEEP_ALIVE = 5  # seconds

warm_up_completed = False
openai_serving_chat: OpenAIServingChat
async_engine_client: AsyncEngineClient
engine_args: AsyncEngineArgs
openai_serving_completion: OpenAIServingCompletion
openai_serving_embedding: OpenAIServingEmbedding
openai_serving_tokenization: OpenAIServingTokenization
# Configure logger for __main__ module. Otherwise the default
# Python logging format will be used by `logger` object in this script.
configure_logger("")
configure_all_loggers_with_handlers_except(
    not_configured_loggers=["vllm_mxext", "uvicorn", ""], keep_original_log_level=True
)
logger = init_logger(__name__)

# When set, error responses consist of a single "error" field set to a message describing the error.
# NOTE: This is not compatible with the OpenAI API. This is a temporary fix so that more helpful
# error message are sent through NVCF and KServe when those are used to depoly instances of
# this server.
api_compat_single_error_field = False

WARM_UP_HEALTH_CHECK_MESSAGE = "Service is starting"
EXAMPLE_CURL_REQUEST = """curl -X 'POST' \\
  'http://{host}:{port}/v1/chat/completions' \\
  -H 'accept: application/json' \\
  -H 'Content-Type: application/json' \\
  -d '{{
    "model": "{model}",
    "messages": [
      {{
        "role":"user",
        "content":"Hello! How are you?"
      }},
      {{
        "role":"assistant",
        "content":"Hi! I am quite well, how can I help you today?"
      }},
      {{
        "role":"user",
        "content":"Can you write me a song?"
      }}
    ],
    "top_p": 1,
    "n": 1,
    "max_tokens": 15,
    "stream": true,
    "frequency_penalty": 1.0,
    "stop": ["hello"]
  }}'
"""


_running_tasks: Set[asyncio.Task] = set()


@asynccontextmanager
async def lifespan(app: FastAPI):

    async def _force_log():
        while True:
            await asyncio.sleep(10)
            await async_engine_client.do_log_stats()

    if not engine_args.disable_log_stats:
        task = asyncio.create_task(_force_log())
        _running_tasks.add(task)
        task.add_done_callback(_running_tasks.remove)

    yield


@asynccontextmanager
async def build_async_engine_client(args) -> AsyncIterator[AsyncEngineClient]:
    # Context manager to handle async_engine_client lifecycle
    # Ensures everything is shutdown and cleaned up on error/exit
    args.chat_template= os.getenv("MIM_LLM_CHAT_TEMPLATE", "/opt/mim/template_chatml_default.jinja")
    global engine_args
    logger.debug(f"LLM AsyncEngineArgs Args: {args}")
    engine_args = AsyncEngineArgs.from_cli_args(args)
    logger.debug(f"AsyncEngineArgs engine_args: {engine_args}")
    
    print_system_and_profile_summaries()
    #downloading models from minIO, you need process AK/SK
    engine_args, extracted_name = inject_mx_hub(engine_args)
    if args.served_model_name is not None:
       served_model_names = args.served_model_name
    else:
       served_model_names = extracted_name
    
    logger.debug(f"after inject_mx_hub engine_args: {engine_args}")
    logger.debug(f"after inject_mx_hub extracted_name: {extracted_name}")
    logger.debug(f"after inject_mx_hub served_model_names: {served_model_names}")
    args.served_model_name = served_model_names
    # Backend itself still global for the silly lil' health handler
    global async_engine_client

    async_engine_client = AsyncLLMEngine.from_engine_args(
        engine_args, usage_context=UsageContext.OPENAI_API_SERVER)
    yield async_engine_client
    return

router = APIRouter()


def mount_metrics(app: FastAPI):
    # Add prometheus asgi middleware to route /metrics requests
    metrics_route = Mount("/metrics", make_asgi_app())
    # Workaround for 307 Redirect for /metrics
    metrics_route.path_regex = re.compile('^/metrics(?P<path>.*)$')
    app.routes.append(metrics_route)

def parse_args():
    # 创建 ArgumentParser 实例
    sys_parser = argparse.ArgumentParser()
    parser = make_arg_parser(sys_parser)
    return parser.parse_args()

async def create_streaming_response(gen: AsyncGenerator[str, None]) -> StreamingResponse:
    #try:
        first_r = await anext(gen)

        async def resp_stream():
            yield first_r
            async for r in gen:
                yield r

        return StreamingResponse(content=resp_stream(), media_type="text/event-stream")


def get_health_success_response(message: str):
    return JSONResponse(
        NIMHealthSuccessResponse(message=message).model_dump(), headers={"System-Health": str(True)}, status_code=200
    )


@router.get(
    "/v1/health/ready",
    response_model=NIMHealthSuccessResponse,
    summary="Service ready check",
    description=dedent(
        """
      This endpoint will return a 200 status when the
      service is ready to receive inference requests
"""
    )
    .replace("\n", " ")
    .strip(),
    responses={
        503: {"description": "Service is not ready to receive requests.", "model": ErrorResponse},
    },
)
async def health() -> Response:
    """Health check.
    Ensures all backend services are ready to serve inference requests.
    """
    try:
        await async_engine_client.check_health()
    except Exception as e:
        logger.exception("Error while checking service health")
        err = openai_serving_chat.create_error_response(
            message="Service in unhealthy",
            err_type="ServiceUnavailableError",
            status_code=HTTPStatus.SERVICE_UNAVAILABLE,
        )
        return JSONResponse(err.model_dump(), status_code=HTTPStatus.SERVICE_UNAVAILABLE)
    return get_health_success_response("Service is ready.")

@router.get("/health")
async def health() -> Response:
    """Health check."""
    await async_engine_client.check_health()
    return Response(status_code=200)



@router.get(
    "/v1/health/live",
    summary="Service liveness check",
    description=dedent(
        """
            This endpoint will return a 200 status as soon as the service
            is able to accept traffic, but it does not mean
            the service is ready to accept inference requests.
        """
    )
    .replace("\n", " ")
    .strip(),
    response_model=Union[NIMHealthSuccessResponse],
)
async def health_ready() -> Response:
    return get_health_success_response("Service is live.")


@router.post("/tokenize")
async def tokenize(request: TokenizeRequest):
    generator = await openai_serving_tokenization.create_tokenize(request)
    if isinstance(generator, ErrorResponse):
        return JSONResponse(content=generator.model_dump(),
                            status_code=generator.code)
    else:
        assert isinstance(generator, TokenizeResponse)
        return JSONResponse(content=generator.model_dump())


@router.post("/detokenize")
async def detokenize(request: DetokenizeRequest):
    generator = await openai_serving_tokenization.create_detokenize(request)
    if isinstance(generator, ErrorResponse):
        return JSONResponse(content=generator.model_dump(),
                            status_code=generator.code)
    else:
        assert isinstance(generator, DetokenizeResponse)
        return JSONResponse(content=generator.model_dump())


@router.get("/v1/models")
async def show_available_models():
    models = await openai_serving_completion.show_available_models()
    return JSONResponse(content=models.model_dump())

# @router.get(
#     "/v1/models",
#     summary="List available models",
#     description=dedent(
#         """
#             This endpoint will return a list of models available for inference.
#             When the MIM is set up to serve customizations (e.g. LoRAs) this will also return the
#             customizations available as models.
#          """
#     )
#     .replace("\n", " ")
#     .strip(),
#     response_model=ModelList,
# )
# async def show_available_models():
#     # print("Request Headers:", request.headers)
#     # print("Request Query Params:", request.query_params)
#     models = await openai_serving_chat.show_available_models()
#     model_dump = models.model_dump()

#     # For now, we always set the "owned_by" field to "system" (it is hard-coded to "vllm" in
#     # the ModelCard class, so we have to overwrite it here). In the future, we may add additional
#     # information to show the provenance of the model.

#     for model in model_dump['data']:
#         model['owned_by'] = 'system'

#     return JSONResponse(content=model_dump)


@router.get(
    "/v1/version",
    summary="Returns version information about this MIM",
    description=dedent(
        """
            The `release` attribute corresponds to the product
            release version of the MIM. The `api` attribute
            is the semver API version running inside the MIM.
         """
    )
    .replace("\n", " ")
    .strip(),
    response_model=NIMLLMVersionResponse,
)
async def show_version():
    ver = NIMLLMVersionResponse(release="1.0.0", api="1.0.0")
    return JSONResponse(content=ver.model_dump())


# @router.post(
#     "/v1/chat/completions",
#     summary="OpenAI-compatible chat endpoint",
#     response_model=Union[ChatCompletionResponse, ChatCompletionStreamResponse],
#     responses={
#         400: {
#             "description": "Received an invalid request possibly containing unsupported or out-of-range parameter values.",
#             "model": ErrorResponse,
#         },
#         404: {"description": "The requested model does not exist.", "model": ErrorResponse},
#         500: {"description": "", "model": ErrorResponse},
#     },
# )
# async def create_chat_completion(request: NIMLLMChatCompletionRequest, raw_request: Request):
#     generator = await openai_serving_chat.create_chat_completion(request, raw_request)
#     if isinstance(generator, ErrorResponse):
#         return _create_error_repsonse(generator)
#     if request.stream:
#         return await create_streaming_response(generator)
#     else:
#         assert isinstance(generator, ChatCompletionResponse)
#         return JSONResponse(content=generator.model_dump())


@router.post("/v1/chat/completions")
async def create_chat_completion(request: ChatCompletionRequest,
                                 raw_request: Request):
    generator = await openai_serving_chat.create_chat_completion(
        request, raw_request)
    if isinstance(generator, ErrorResponse):
        return JSONResponse(content=generator.model_dump(),
                            status_code=generator.code)
    if request.stream:
        return StreamingResponse(content=generator,
                                 media_type="text/event-stream")
    else:
        assert isinstance(generator, ChatCompletionResponse)
        return JSONResponse(content=generator.model_dump())

# @router.post(
#     "/v1/completions",
#     summary="OpenAI-compatible completions endpoint",
#     response_model=Union[CompletionResponse, CompletionStreamResponse],
#     responses={
#         400: {
#             "description": "Received an invalid request possibly containing unsupported or out-of-range parameter values.",
#             "model": ErrorResponse,
#         },
#         404: {"description": "The requested model does not exist.", "model": ErrorResponse},
#         500: {"description": "", "model": ErrorResponse},
#     },
# )
# async def create_completion(request: NIMLLMCompletionRequest, raw_request: Request):
#     generator = await openai_serving_completion.create_completion(request, raw_request)
#     if isinstance(generator, ErrorResponse):
#         return _create_error_repsonse(generator)
#     if request.stream:
#         return await create_streaming_response(generator)
#     else:
#         return JSONResponse(content=generator.model_dump())

@router.post("/v1/completions")
async def create_completion(request: CompletionRequest, raw_request: Request):
    generator = await openai_serving_completion.create_completion(
        request, raw_request)
    if isinstance(generator, ErrorResponse):
        return JSONResponse(content=generator.model_dump(),
                            status_code=generator.code)
    if request.stream:
        return StreamingResponse(content=generator,
                                 media_type="text/event-stream")
    else:
        return JSONResponse(content=generator.model_dump())
    
@router.post("/v1/embeddings")
async def create_embedding(request: EmbeddingRequest, raw_request: Request):
    generator = await openai_serving_embedding.create_embedding(
        request, raw_request)
    if isinstance(generator, ErrorResponse):
        return JSONResponse(content=generator.model_dump(),
                            status_code=generator.code)
    else:
        return JSONResponse(content=generator.model_dump())

def _create_error_repsonse(original: ErrorResponse, *, status_code: Optional[int] = None) -> JSONResponse:
    content = original.model_dump()

    if api_compat_single_error_field:
        content = {'error': content['message']}

    if status_code is None:
        status_code = original.code

    return JSONResponse(content=content, status_code=status_code)
    

def complete_args_with_env_vars():
    args = parse_args()

    class EnvConfig:
        def __init__(self, env_name, arg_name, type_, default_value=None):
            self.env_name = env_name
            self.arg_name = arg_name
            self.type = type_
            self.default_value = default_value

    env_vars = [
        EnvConfig("MIM_MODEL_NAME", "model", str),
        EnvConfig("UVICORN_LOG_LEVEL", "uvicorn_log_level", str),
        EnvConfig("MIM_PEFT_SOURCE", "peft_source", str),
        EnvConfig("MIM_SERVER_PORT", "port", int),
        EnvConfig("MIM_MAX_LORA_RANK", "max_lora_rank", int, "32"),
        EnvConfig("MIM_PEFT_REFRESH_INTERVAL", "peft_refresh_interval", int),
        EnvConfig("MIM_DISABLE_LOG_REQUESTS", "disable_log_requests", lambda x: x != "0"),
        EnvConfig("MIM_API_COMPAT_SINGLE_ERROR_FIELD", "api_compat_single_error_field", bool),
        EnvConfig("MIM_MAX_GPU_LORAS", "max_loras", int, "8"),
        EnvConfig("MIM_MAX_CPU_LORAS", "max_cpu_loras", int, "16"),
        EnvConfig("MIM_MAX_Moel_LEN", "max_model_len", int),
        EnvConfig("MIM_WORK_USE_RAY", "worker_use_ray", bool, False),
        EnvConfig("MIM_BLOCK_SIZE", "block_size", int, 16),
        EnvConfig("MIM_GPU_MEMORY_UTILIZATION", "gpu_memory_utilization", float, 0.9),
        EnvConfig("MIM_TRUST_REMOTE_CODE", "trust_remote_code", bool, False),
    ]

    # Disable request logging by default
    setattr(args, "disable_log_requests", True)

    setattr(args, "api_compat_single_error_field", False)

    for config in env_vars:
        value = os.getenv(config.env_name, config.default_value)
        if value is not None:
            try:
                setattr(args, config.arg_name, config.type(value))
            except ValueError as e:
                logger.exception(f"Invalid value used for {config.env_name}: {value}")
                raise e

    if getattr(args, "peft_source", None) is not None:
        setattr(args, "enable_lora", True)

    return args


def log_served_endpoints(app: fastapi.FastAPI, host: str | None, port: int) -> List[str]:
    message = "Serving endpoints:\n  "
    endpoints_str = "\n  ".join([f"{'0.0.0.0' if host is None else host}:{port}{route.path}" for route in app.routes])
    logger.info(message + endpoints_str)


def log_example_curl_request(model: str, host: str | None, port: int) -> None:
    logger.info(
        f"An example cURL request:\n"
        + EXAMPLE_CURL_REQUEST.format(model=model, host="0.0.0.0" if host is None else host, port=port),
    )

def build_app(args: Namespace) -> FastAPI:
    
    app = fastapi.FastAPI(
        lifespan=lifespan,
        title="Metax MIM for LLMs",
        version=vllm_mxext.__version__,
        summary="Accelerated LLM inference for Metax GPUs.",
        # TODO: pull in model card if it exists?
        description="",
        redoc_url=None,
    )
    app.include_router(router)
    app.root_path = args.root_path

    mount_metrics(app)
    api_compat_single_error_field = args.api_compat_single_error_field
    app.add_middleware(
        CORSMiddleware,
        allow_origins=args.allowed_origins,
        allow_credentials=args.allow_credentials,
        allow_methods=args.allowed_methods,
        allow_headers=args.allowed_headers,
    )

    @app.exception_handler(RequestValidationError)
    async def validation_exception_handler(_, exc):
        err = openai_serving_chat.create_error_response(message=str(exc))
        return JSONResponse(err.model_dump(),
                            status_code=HTTPStatus.BAD_REQUEST)

    if token := envs.VLLM_API_KEY or args.api_key:

        @app.middleware("http")
        async def authentication(request: Request, call_next):
            root_path = "" if args.root_path is None else args.root_path
            if request.method == "OPTIONS":
                return await call_next(request)
            if not request.url.path.startswith(f"{root_path}/v1"):
                return await call_next(request)
            if request.headers.get("Authorization") != "Bearer " + token:
                return JSONResponse(content={"error": "Unauthorized"},
                                    status_code=401)
            return await call_next(request)

    for middleware in args.middleware:
        module_path, object_name = middleware.rsplit(".", 1)
        imported = getattr(importlib.import_module(module_path), object_name)
        if inspect.isclass(imported):
            app.add_middleware(imported)
        elif inspect.iscoroutinefunction(imported):
            app.middleware("http")(imported)
        else:
            raise ValueError(f"Invalid middleware {middleware}. "
                             f"Must be a function or a class.")

    return app

async def init_app(
    async_engine_client: AsyncEngineClient,
    args: Namespace,
) -> FastAPI:
    #args = complete_args_with_env_vars()
    app = build_app(args)
    api_compat_single_error_field = args.api_compat_single_error_field

    app = build_app(args)
    served_model_names = [args.served_model_name]

    model_config = await async_engine_client.get_model_config()

    if args.disable_log_requests:
        request_logger = None
    else:
        request_logger = RequestLogger(max_log_len=args.max_log_len)

    global openai_serving_chat
    global openai_serving_completion
    global openai_serving_embedding
    global openai_serving_tokenization

    logger.info(f"MIM LLM API version {vllm_mxext.__version__}")

    NimMetrics.unify_vllm_metrics(engine_args.max_num_seqs, async_engine_client.engine.stat_loggers)

    model_config = await async_engine_client.get_model_config()
    openai_serving_chat = OpenAIServingChat(
        async_engine_client, 
        model_config,
        served_model_names,
        args.response_role,
        lora_modules=args.lora_modules,
        prompt_adapters=None,
        request_logger=None,
        chat_template=args.chat_template
    )
    openai_serving_completion = OpenAIServingCompletion(async_engine_client,
                                                        model_config,
                                                        served_model_names,
                                                        lora_modules=args.lora_modules,
                                                        prompt_adapters=None,
                                                        request_logger=request_logger)
    
    openai_serving_embedding = OpenAIServingEmbedding(
        async_engine_client,
        model_config,
        served_model_names,
        request_logger=request_logger,
    )
    openai_serving_tokenization = OpenAIServingTokenization(
        async_engine_client,
        model_config,
        served_model_names,
        lora_modules=args.lora_modules,
        request_logger=request_logger,
        chat_template=args.chat_template,
    )
    app.root_path = args.root_path
    
    app.root_path = args.root_path
    log_served_endpoints(app, args.host, args.port)
    log_example_curl_request(served_model_names[0], args.host, args.port)
    return app

    
    
    
async def run_server(args, **uvicorn_kwargs) -> None:
    logger.info("vLLM API server version %s", VLLM_VERSION)
    logger.info("args: %s", args)

    async with build_async_engine_client(args) as async_engine_client:
        app = await init_app(async_engine_client, args)

        shutdown_task = await serve_http(
            app,
            host=args.host,
            port=args.port,
            log_level=args.uvicorn_log_level,
            timeout_keep_alive=TIMEOUT_KEEP_ALIVE,
            ssl_keyfile=args.ssl_keyfile,
            ssl_certfile=args.ssl_certfile,
            ssl_ca_certs=args.ssl_ca_certs,
            ssl_cert_reqs=args.ssl_cert_reqs,
            **uvicorn_kwargs,
        )

    # NB: Await server shutdown only after the backend context is exited
    await shutdown_task


if __name__ == "__main__":
    # NOTE(simon):
    # This section should be in sync with vllm/scripts.py for CLI entrypoints.
    # parser = FlexibleArgumentParser(
    #     description="vLLM OpenAI-Compatible RESTful API server.")
    # parser = make_arg_parser(parser)
    # args = parser.parse_args()
    args = complete_args_with_env_vars()
    asyncio.run(run_server(args))